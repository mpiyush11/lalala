import Link from 'next/link';

import { ownerCopy as copy } from '@/lib/copy/owner';
import { formatMoney } from '@/lib/format/currency';

export type CockpitMetrics = {
  bankUpiTodayMinor: number;
  cashDrawerMinor: number;
  duesCount: number;
  duesTotalMinor: number;
  revenueTodayMinor: number;
};

/**
 * Shared surface so a linked tile and a static tile read as the same object.
 *
 * `border-zinc-800` rather than a zinc step: a translucent hairline keeps the
 * edge consistent whatever sits behind it, and stays visible on the glare of a
 * phone screen at a gym counter.
 */
const TILE =
  'flex min-w-0 flex-col rounded-xl border border-zinc-800 bg-zinc-950/60 p-4 transition-transform sm:p-5';

/**
 * Uppercase micro-label — present but never competing with the figure.
 *
 * Deliberately NOT truncated: at 360px "Total Revenue Today" and "Total Pending
 * Dues" both clipped to "TOTAL REVENUE T…", which reads as a bug. A two-line
 * wrap costs one row of height and keeps every tile legible; `min-h` reserves
 * that second line so all four tiles keep a common baseline.
 */
const LABEL =
  'text-[10px] font-semibold uppercase leading-tight tracking-wider text-zinc-400 sm:min-h-[1.6em]';

/**
 * The headline figure.
 *
 * Tabular numerals so the four tiles align digit-for-digit in the 2x2 grid;
 * `tracking-tight` claws back the width that a long rupee figure costs at
 * 360px, which is what previously forced truncation.
 */
const FIGURE = 'mt-2 truncate text-2xl font-bold tracking-tight tabular-nums text-white sm:text-3xl';

function Tile({ label, testId, value }: { label: string; testId: string; value: string }) {
  return (
    <div data-testid={testId} className={TILE}>
      <p className={LABEL}>{label}</p>
      <p className={FIGURE}>{value}</p>
    </div>
  );
}

/**
 * The four numbers an owner opens the app to see.
 *
 * Read-only by design: this screen is a business monitor, not a control panel.
 * Anything that needs a decision lives on its own tab, which is why the dues
 * tile is the only one that navigates — and why it is the only one that carries
 * a press affordance.
 */
export function MetricTiles({ metrics }: { metrics: CockpitMetrics }) {
  return (
    <section
      data-testid="metric-tiles"
      aria-label={copy.home.totalRevenue}
      className="grid grid-cols-2 gap-3 lg:grid-cols-4"
    >
      <Tile
        testId="metric-revenue"
        label={copy.home.totalRevenue}
        value={formatMoney(metrics.revenueTodayMinor)}
      />
      <Tile
        testId="metric-cash"
        label={copy.home.cashDrawer}
        value={formatMoney(metrics.cashDrawerMinor)}
      />
      <Tile
        testId="metric-upi"
        label={copy.home.bankUpi}
        value={formatMoney(metrics.bankUpiTodayMinor)}
      />

      {/* The one actionable tile. The arrow and the press-scale are the only
          signals that distinguish a destination from a fact, so both stay. */}
      <Link
        href="/owner/dues"
        data-testid="metric-dues"
        className={`${TILE} group hover:border-zinc-700 active:scale-[0.98]`}
      >
        <p className={LABEL}>{copy.home.pendingDues}</p>
        <p className={FIGURE}>{formatMoney(metrics.duesTotalMinor)}</p>
        <p className="mt-auto flex items-center gap-1 truncate pt-1.5 text-[10px] font-medium text-zinc-400">
          <span className="truncate">{copy.home.tapToView}</span>
          <span
            aria-hidden="true"
            className="shrink-0 transition-transform group-hover:translate-x-0.5"
          >
            →
          </span>
        </p>
      </Link>
    </section>
  );
}
