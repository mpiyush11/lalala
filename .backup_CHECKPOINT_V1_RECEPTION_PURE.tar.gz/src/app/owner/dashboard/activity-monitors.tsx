import Link from 'next/link';

import { ownerCopy as copy } from '@/lib/copy/owner';
import { formatMoney } from '@/lib/format/currency';

export type CollectionEntry = {
  amountMinor: number;
  id: string;
  memberName: string;
  /** Raw ISO instant, used only for ordering. */
  occurredAt: string;
  staffName: string;
  tender: 'CASH' | 'UPI' | 'SPLIT';
  time: string;
};

export type ExpenseEntry = {
  amountMinor: number;
  category: string;
  id: string;
  note: string | null;
  /** Raw ISO instant, used only for ordering. */
  occurredAt: string;
  staffName: string;
  time: string;
};

/** One shape for both sides of the ledger, so they can share a table. */
type LedgerRow = {
  amountMinor: number;
  direction: 'in' | 'out';
  id: string;
  label: string;
  occurredAt: string;
  staffName: string;
  tag: string;
  time: string;
};

function toRows(collections: CollectionEntry[], expenses: ExpenseEntry[]): LedgerRow[] {
  const inflow: LedgerRow[] = collections.map((entry) => ({
    amountMinor: entry.amountMinor,
    direction: 'in',
    id: `c-${entry.id}`,
    label: entry.memberName,
    occurredAt: entry.occurredAt,
    staffName: entry.staffName,
    tag: entry.tender,
    time: entry.time,
  }));

  const outflow: LedgerRow[] = expenses.map((entry) => ({
    amountMinor: entry.amountMinor,
    direction: 'out',
    id: `e-${entry.id}`,
    label: entry.note
      ? `${copy.expenses.categories[entry.category] ?? entry.category} · ${entry.note}`
      : (copy.expenses.categories[entry.category] ?? entry.category),
    occurredAt: entry.occurredAt,
    staffName: entry.staffName,
    tag: 'OUT',
    time: entry.time,
  }));

  // Newest first, ordered on the raw instant. Sorting the rendered 12-hour
  // string silently misorders across noon — "10:42 am" compares above
  // "09:42 pm" — which is exactly the kind of quiet wrongness a cash log
  // cannot carry.
  return [...inflow, ...outflow].sort((a, b) => b.occurredAt.localeCompare(a.occurredAt));
}

/**
 * Today's realtime audit log.
 *
 * Money in and money out were previously two separate cards, each collapsing
 * to a tall empty box with one line of grey text — a pair of dead wireframes
 * for most of the morning. They are one ledger now: the same rows the front
 * desk sees, sorted newest-first, with direction carried by a signed amount
 * rather than by which box a row happens to sit in.
 */
export function RealtimeAuditLog({
  collections,
  expenses,
}: {
  collections: CollectionEntry[];
  expenses: ExpenseEntry[];
}) {
  const rows = toRows(collections, expenses);

  return (
    <section className="min-w-0">
      <div className="mb-2 flex items-baseline justify-between gap-3">
        <h2 className="text-[10px] font-semibold uppercase tracking-wider text-zinc-400">
          {copy.home.auditTitle}
        </h2>
        {rows.length ? (
          <Link
            href="/owner/staff"
            data-testid="view-shift-log"
            className="shrink-0 text-xs text-zinc-500 transition hover:text-zinc-300"
          >
            {copy.home.viewShiftLog}
          </Link>
        ) : null}
      </div>

      {rows.length ? (
        <div
          data-testid="audit-log"
          className="overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950/60"
        >
          <ul className="divide-y divide-zinc-800/80">
            {rows.map((row) => (
              <li
                key={row.id}
                data-testid="audit-row"
                data-direction={row.direction}
                className="flex min-w-0 items-center gap-3 px-4 py-2.5 transition-colors hover:bg-zinc-900/60"
              >
                {/* Timestamp — fixed column so the whole log scans vertically. */}
                <span className="w-[68px] shrink-0 font-mono text-[11px] tabular-nums text-zinc-500">
                  {row.time}
                </span>

                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-medium text-zinc-100">
                    {row.label}
                  </span>
                  <span className="mt-0.5 block truncate text-[11px] text-zinc-500">
                    {row.staffName}
                  </span>
                </span>

                <span
                  data-testid="tender-badge"
                  className="hidden shrink-0 rounded border border-zinc-800 px-1.5 py-0.5 text-[10px] font-medium text-zinc-400 sm:inline-block"
                >
                  {row.tag}
                </span>

                <span
                  className={`w-24 shrink-0 text-right text-sm font-bold tabular-nums ${
                    row.direction === 'in' ? 'text-emerald-400' : 'text-zinc-400'
                  }`}
                >
                  {row.direction === 'in' ? '+' : '−'}
                  {formatMoney(row.amountMinor)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      ) : (
        /* Low-profile status strip, not an empty container. One line tall. */
        <p
          data-testid="audit-empty"
          className="flex items-center gap-2 rounded-lg border border-zinc-800 bg-zinc-950/60 px-3 py-2 text-xs text-zinc-500"
        >
          <span aria-hidden="true" className="h-1.5 w-1.5 shrink-0 rounded-full bg-zinc-600" />
          {copy.home.auditEmpty}
        </p>
      )}
    </section>
  );
}
