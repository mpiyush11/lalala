import { redirect } from 'next/navigation';
import type { ReactNode } from 'react';

import { OwnerBottomNav, OwnerBottomNavSpacer, OwnerMobileHeader } from '@/components/owner-bottom-nav';
import { OwnerSidebar } from '@/components/owner-sidebar';
import { getCurrentUser } from '@/lib/auth';
import { createClient } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

/**
 * Owner Cockpit shell.
 *
 * Desktop (>= 1024px) gets a persistent left sidebar and the content column is
 * inset by its width. Phones get a sticky header plus a four-tab bottom bar.
 *
 * Defence in depth: middleware already blocks `/owner/*` for non-owners, but
 * the guard is repeated here so a direct render can never leak drawer figures
 * and staff attribution. RLS remains the final boundary on the data itself.
 */
export default async function OwnerLayout({ children }: { children: ReactNode }) {
  const currentUser = await getCurrentUser();

  if (!currentUser) redirect('/login');

  if (currentUser.role !== 'owner' && currentUser.role !== 'superadmin') {
    redirect('/dashboard?auth_error=forbidden&status=403');
  }

  const supabase = await createClient();
  const [tenantResult, shiftResult] = await Promise.all([
    supabase.from('tenants').select('name').eq('tenant_id', currentUser.tenantId).single(),
    supabase
      .from('shifts')
      .select('staff_id')
      .eq('tenant_id', currentUser.tenantId)
      .eq('status', 'OPEN')
      .limit(1)
      .maybeSingle(),
  ]);

  const gymName = tenantResult.data?.name ?? 'GymOS';

  let onDeskStaffName: string | null = null;
  if (shiftResult.data?.staff_id) {
    const { data: staff } = await supabase
      .from('users')
      .select('full_name')
      .eq('id', shiftResult.data.staff_id)
      .single();
    onDeskStaffName = staff?.full_name ?? null;
  }

  // `bg-canvas` (#121212) is the exact token the front desk shell uses. Parity
  // matters more than a darker hex here: the tactical look comes from cards
  // being DARKER than the shell (zinc-950/60 over #121212) behind a crisp
  // zinc-800 hairline — not from the page itself being pitch black. The owner
  // panel previously ran a zinc-950 shell under #111 cards, which is exactly
  // why it read muddy: only a few points of luminance separated the two.
  return (
    <div className="min-h-screen bg-canvas text-zinc-100">
      <OwnerSidebar
        gymName={gymName}
        onDeskStaffName={onDeskStaffName}
        ownerName={currentUser.profile.full_name}
      />

      <div className="lg:pl-[68px] xl:pl-[232px]">
        <OwnerMobileHeader
          gymName={gymName}
          onDeskStaffName={onDeskStaffName}
          ownerName={currentUser.profile.full_name}
        />
        {/* Constrained workspace: never stretches edge-to-edge on wide screens. */}
        {/* Reading container. At 1440px the dues rows previously spanned ~1050px,
            leaving a member name and their balance a full screen-width apart.
            5xl keeps both inside one eye-scan. */}
        <main className="mx-auto w-full max-w-5xl px-4 py-4 sm:px-6 lg:px-8">{children}</main>
        <OwnerBottomNavSpacer />
      </div>

      <OwnerBottomNav />
    </div>
  );
}
